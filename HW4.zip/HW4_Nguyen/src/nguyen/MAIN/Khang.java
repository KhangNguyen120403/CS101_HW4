package nguyen.MAIN;

import nguyen.FACTORY.VirusBuilder;
import nguyen.INTERFACE.Viral;
import nguyen.VIRUS.A_Virus;
import nguyen.VIRUS.ComputerVirus;

public class Khang {
	public static void main(String[] args) {
		ComputerVirus[] viruses = VirusBuilder.buildViruses(3,4,1);
		//A_Virus alpha = new A_Virus(Viral.generateID(), "Spyware", "File Download", "Linux", false);
		//alpha.displayMe();
		VirusBuilder.displayViruses(viruses);
		//A_Virus virus = new A_Virus("A1", 4);
	}
}
