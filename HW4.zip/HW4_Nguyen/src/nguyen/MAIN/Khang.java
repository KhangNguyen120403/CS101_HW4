package nguyen.MAIN;

import nguyen.FACTORY.VirusBuilder;
import nguyen.VIRUS.ComputerVirus;

public class Khang {
	public static void main(String[] args) {
		ComputerVirus[] viruses = VirusBuilder.buildViruses(1,1,1);
		VirusBuilder.displayViruses(viruses);
		String awefaew = "awefaew";
	}
}
