package nguyen.VIRUS;

public class C_Virus {

}
