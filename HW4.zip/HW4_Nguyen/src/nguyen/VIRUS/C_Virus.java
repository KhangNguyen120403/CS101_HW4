package nguyen.VIRUS;

public class C_Virus extends ComputerVirus {
	
	private String CCode = "VIRUS_GAMMA";
	private String virusName = "C" + getVirusID();
	private int virusSize = 8;
	

	public C_Virus(String virusID, String virusPayload, String virusTrigger, String virusTarget, boolean isEncrypted) {
		super(virusID, "C" + virusID, 8, virusPayload, virusTrigger, virusTarget, isEncrypted);
		this.CCode = "VIRUS_GAMMA";
	}
	public void displayMe() {
		System.out.print("***C Virus*** \n" + "CCode: " + this.CCode + "\n" +
		super.toString());
	}
}
