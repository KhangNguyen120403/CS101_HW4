package nguyen.VIRUS;

import nguyen.INTERFACE.Viral;

public abstract class ComputerVirus implements Viral {
	private String virusID;
	private String virusName;
	private int virusSize;
	private String virusPayload;
	private String virusTrigger;
	private String virusTarget;
	private boolean isEncrypted;
	public int virusCount = 0;
	public ComputerVirus() {
		virusCount++;
	}
	public ComputerVirus(String virusID, String virusName, int virusSize, String virusPayload, String virusTrigger, String virusTarget, boolean isEncrypted) {
		this.virusID = virusID;
		this.virusName = virusName;
		this.virusPayload = virusPayload;
		this.virusSize = virusSize;
		this.virusTarget = virusTarget;
		this.isEncrypted = isEncrypted;
		this.virusTrigger = virusTrigger;
		virusCount++;
	}
	public String getVirusID() {
		return virusID;
	}
	public void setVirusID(String virusID) {
		this.virusID = virusID;
	}
	public String getVirusName() {
		return virusName;
	}
	public void setVirusName(String virusName) {
		this.virusName = virusName;
	}
	public int getVirusSize() {
		return virusSize;
	}
	public void setVirusSize(int virusSize) {
		this.virusSize = virusSize;
	}
	public String getVirusPayload() {
		return virusPayload;
	}
	public void setVirusPayload(String virusPayload) {
		this.virusPayload = virusPayload;
	}
	public String getVirusTrigger() {
		return virusTrigger;
	}
	public void setVirusTrigger(String virusTrigger) {
		this.virusTrigger = virusTrigger;
	}
	public String getVirusTarget() {
		return virusTarget;
	}
	public void setVirusTarget(String virusTarget) {
		this.virusTarget = virusTarget;
	}
	public boolean isEncrypted() {
		return isEncrypted;
	}
	public void setEncrypted(boolean isEncrypted) {
		this.isEncrypted = isEncrypted;
	}
	public int getVirusCount() {
		return virusCount;
	}
	public void setVirusCount(int virusCount) {
		this.virusCount = virusCount;
	}
	public String toString() {
		String s = "abc";
		if (this.isEncrypted == true) {
			s = "YES";
		}
		else if (this.isEncrypted == false) {
			s = "NO";
		}
		String a ="Virus ID: " + this.getVirusID() + "\n";
		String b = "Virus Name: " + this.getVirusName() + "\n";
		String c = "Virus Size: " + this.getVirusSize() + "\n";
		String d =		"Virus Payload: " + this.getVirusPayload() + "\n";
		String e =		"Virus Trigger: " + this.getVirusTrigger() + "\n";
		String f = 		"Virus Target: " + this.getVirusTarget() + "\n";
		String g =		"Encrypted: " +  s;
		String word = a + b + c + d + e + f + g;
		return word;
	}
}
