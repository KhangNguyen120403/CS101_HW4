package nguyen.VIRUS;

public class A_Virus extends ComputerVirus {
	
	private String ACode;
	private String virusName = "A" + getVirusID();
	private int virusSize = 4;


	public A_Virus(String virusID, String virusPayload, String virusTrigger,
			String virusTarget, boolean isEncrypted) {
		super(virusID, "A" + virusID, 4, virusPayload, virusTrigger, virusTarget, isEncrypted);
		this.ACode = "VIRUS_ALPHA";
	}

	public void displayMe() {
		System.out.print("***A Virus*** \n" + "ACode: " + this.ACode + "\n" +
		super.toString() + "\n");
	}
}
