package nguyen.VIRUS;

public class A_Virus {

}
