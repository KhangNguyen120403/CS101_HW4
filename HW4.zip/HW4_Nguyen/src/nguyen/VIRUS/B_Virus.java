package nguyen.VIRUS;

public class B_Virus {

}
