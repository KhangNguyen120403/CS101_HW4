package nguyen.VIRUS;

public class B_Virus extends ComputerVirus {
	
	private String BCode = "VIRUS_BETA";
	private String virusName = "B" + getVirusID();
	private int virusSize = 6;
	


	public B_Virus(String virusID, String virusPayload, String virusTrigger, String virusTarget, boolean isEncrypted) {
		super(virusID, "B" + virusID, 6, virusPayload, virusTrigger, virusTarget, isEncrypted);
		this.BCode = "VIRUS_BETA";
	}
	public void displayMe() {
		System.out.print("***B Virus*** \n" + "BCode: " + this.BCode + "\n" +
		super.toString() + "\n");
	}
}
