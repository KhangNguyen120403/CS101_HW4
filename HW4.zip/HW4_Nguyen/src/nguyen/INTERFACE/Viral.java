package nguyen.INTERFACE;

public interface Viral {
	public static String[] ltrs = {"A", "B", "C", "D", "E", "F"};
	public static String[] digits = {"1", "2", "3", "4", "5", "6"};
	public static String[] payload = {"Worm", "Trojan Horse", "Spyware"};
	public static String[] trigger = {"File Download", "Macro Run"};
	public static String[] target = {"Windows", "Linux"};
	
	public abstract void displayMe();
	
	public static String generateID() {
		String first_ltrs = ltrs[(int)(Math.random()*ltrs.length)];
		String second_digits = digits[(int)(Math.random()*digits.length)];
		String third_ltrs = ltrs[(int)(Math.random()*ltrs.length)];
		String sequence = first_ltrs + second_digits + third_ltrs;
		return sequence;
	}
}
