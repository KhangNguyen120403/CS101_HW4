package nguyen.INTERFACE;

public class Viral {

}
