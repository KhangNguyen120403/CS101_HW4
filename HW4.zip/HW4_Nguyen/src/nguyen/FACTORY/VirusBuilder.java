package nguyen.FACTORY;

import nguyen.INTERFACE.Viral;
import nguyen.VIRUS.A_Virus;
import nguyen.VIRUS.B_Virus;
import nguyen.VIRUS.C_Virus;
import nguyen.VIRUS.ComputerVirus;

public class VirusBuilder{
	public static ComputerVirus[] buildViruses(int A, int B, int C) {
		ComputerVirus[] array = new ComputerVirus[A + B + C];
		for (int i = 0; i < A; i++) {
			A_Virus AlphaVirus = new A_Virus(Viral.generateID(), "Spyware", "File Download", "Linux", false);
			array[i] = AlphaVirus;
		}
		for (int i = 0; i < B; i++) {
			B_Virus BetaVirus = new B_Virus(Viral.generateID(), "Spyware", "File Download", "Linux", false);
			array[i+A] = BetaVirus;
		}
		for (int i = 0; i < C; i++) {
			C_Virus GammaVirus = new C_Virus(Viral.generateID(), "Spyware", "File Download", "Linux", true);
			array[i + A + B] = GammaVirus;
		}
		return array;
	}

	public static void displayViruses(ComputerVirus[] viruses) {
		for (int i = 0; i < viruses.length; i++) {
			viruses[i].displayMe();
			System.out.println();
		}
	}
}
