package nguyen.FACTORY;

import nguyen.VIRUS.ComputerVirus;

public class VirusBuilder {

	public static ComputerVirus[] buildViruses(int i, int j, int k) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void displayViruses(ComputerVirus[] viruses) {
		// TODO Auto-generated method stub
		
	}

}
